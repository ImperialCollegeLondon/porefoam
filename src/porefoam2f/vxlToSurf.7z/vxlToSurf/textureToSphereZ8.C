/*-------------------------------------------------------------------------*\	
You can redistribute this code and/or modify this code under the 
terms of the GNU General Public License (GPL) as published by the  
Free Software Foundation, either version 3 of the License, or (at 
your option) any later version. see <http://www.gnu.org/licenses/>.


The code has been developed by Ahmed AlRatrout as a part his PhD 
at Imperial College London, under the supervision of Dr. Branko Bijeljic 
and Prof. Martin Blunt. 

Please see our website for relavant literature:
AlRatrout et al, AWR, 2017 - https://www.sciencedirect.com/science/article/pii/S0309170817303342
AlRatrout et al, WRR, 2018 - https://agupubs.onlinelibrary.wiley.com/doi/pdf/10.1029/2017WR022124
AlRatrout et al, PNAS, 2018 - http://www.pnas.org/

For further information please contact us by email:
Ahmed AlRarout:  a.alratrout14@imperial.ac.uk
Branko Bijeljic: b.bijeljic@imperial.ac.uk
Martin J Blunt:  m.blunt@imperial.ac.uk

Description
    Volume-preserving Gaussian and curvature uniform smoothing and contact angle measurement

\*---------------------------------------------------------------------------*/

#include "InputFile.h"


#include "globals.cpp"
int main(int argc, char *argv[])
{

	//#   include "setRootCase.H"
	//#   include "createTime.H"
	//runTime++;
	//Info<< "Time = " << runTime.timeName() << "\n" << endl;
    //IOdictionary meshingDict
    //(
        //IOobject
        //(
            //"meshingDict",
            //runTime.system(),
            //runTime,
            //IOobject::MUST_READ,
            //IOobject::NO_WRITE
        //)
    //);
	std::cout<<argv[1]<<std::endl;
    InputFile meshingDict((std::string)(argv[1]));
    meshingDict.echoKeywords(std::cout);
    word surfFileName(meshingDict.getOr(std::string("Chomic251Cyl.vtk"),"inputSurface"));
    fileName outFileName(meshingDict.getOr(std::string("surfSmooth.vtk"),"outputSurface"));
    int solidIndex(meshingDict.getOr(1024,"solidIndex"));
    const int oilWaterIndex(meshingDict.getOr(512,"oilWaterIndex"));






    Info<< "Reading surface from " << surfFileName << " ..." << endl;

    meshedSurface surf123(surfFileName);


    Info<< "nFaces    : " << surf123.size() << endl;
    Info<< "nVertices     : " << surf123.nPoints() << endl;
    Info<< "nZones     : " << surf123.surfZones().size() << endl;
    Info<< "Bounding Box : " << boundBox(surf123.localPoints()) << endl;




    #define labelLoop face

    const pointField & points=surf123.points();
    const List<face> & faces=surf123.surfFaces();


    pointField newPoints(points);

    Info<<"\n........"<<endl<<endl ;
//~ exit(-1);


	vector  Cntr(0.0,0.0,0.0);
	for_i(points) Cntr+=points(i);
	Cntr /= points.size();



	voxelImageT<float> elevations("elevationMap.mhd");

	nnElv = elevations.size3();

	dbl3 X0Phi = meshingDict.getOr(dbl3(0.0,0.0,1.0),"X0Phi");
	dbl3 X0Theta = meshingDict.getOr(dbl3(0.0,0.0,1.0),"X0Theta");
	dbl3 X1Theta = meshingDict.getOr(dbl3(0.0,0.0,1.0),"X1Theta");
	double scaleXY = meshingDict.getOr(0.0,"scaleXY");
	double scaleRoughness = meshingDict.getOr(0.0,"scaleRoughness");




	for_i(newPoints)
	{
		Pi=points(i)-Cntr;
		double theta = atan2(Pi[1],Pi[0]);
		double phi = acos(Pi[2]/mag(Pi));

		double wtheta = theta/PI*2.0 - floor(theta/PI*2.0);   if( int(theta/PI*2.0)%2 ) wtheta = 1.0-wtheta;
		double wphi   = phi  /PI*2.0 - floor(phi  /PI*2.0);   if( int(phi  /PI*2.0)%2 ) wphi   = 1.0-wphi;
		dbl3 ij = scaleXY* (1.0-wphi)* X0Phi + wphi*( (1.0-wtheta)* X0Theta + wtheta*X1Theta );
		if(ij.[0]<nnElv[0] && ij.[1]<nnElv[1])
			newPoints[i] += scaleRoughness * elevations(ij[0],ij[1],1);
	}




	for(auto theta0:{0.0, 0.5*PI, PI, 1.5*PI})
	for(auto phi0:{0.0, 0.5*PI})
	{
		dbl3 X0=
		for(auto dtheta:{0.2*PI,0.3*PI})
		for(auto dphi:{0.2*PI,0.3*PI})
		{
		}
	}




	surf123.movePoints(newPoints);


	Info<<average(mag(surf123.points()))<< "  :avgMagPoints    "<<endl;
	Info<<max(mag(surf123.points()))<< "  :maxMagPoints    "; cout.flush();

	//Info<<"triangulating the surface before write"<<endl;
	//surf123.triangulate();


    Info<< "Writing surface to " << outFileName << " ..." << endl;
    surf123.write(outFileName);


    Info << "End\n" << endl;

    return 0;
}


// ************************************************************************* //
