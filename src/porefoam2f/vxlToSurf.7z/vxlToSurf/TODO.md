add read_obj
