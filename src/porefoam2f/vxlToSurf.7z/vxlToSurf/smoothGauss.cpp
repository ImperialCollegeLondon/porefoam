
    //Volume-preserving Gaussian smoothing

#include "InputFile.h"
#include "surfUtils.h"

using namespace std;
int  smoothSurf(InputFile& meshingDict, facePieceList& facezsZ, piece<point> pointsAll)
{
	Info<<"\n... smoothing surface ..."<<endl<<endl ;

	//word surfFileName(meshingDict.getOr(std::string("Chomic251Cyl.vtk"),"inputSurface"));
	//fileName outFileName(meshingDict.getOr(std::string("surfSmooth.vtk"),"outputSurface"));
	int solidIndex(meshingDict.getOr(1024,"solidIndex"));
	const int OWInd(meshingDict.getOr(512,"oilWaterIndex"));

	scalar relaxParIntrf(meshingDict.getOr(0.1,"relaxParIntrf"));
	int kernelRadius(meshingDict.getOr(6,"kernelRadiusGaussVP"));
	int nIters(meshingDict.getOr(8,"nIterationsGaussVP"));
	scalar relax(meshingDict.getOr(0.2,"relaxFactorGaussVP"));  ensure(0<=relax && relax<=1, "Illegal relaxation factor:\n 0: no change, 1: move vertices to average of neighbours",2);
	scalar relaxCL(meshingDict.getOr(0.1,"relaxFactorGaussVPCL"));
	Info<< "Relax:" << relax << endl;
	Info<< "Relax CL:" << relaxCL << endl;
	Info<< "kernel radius:" << kernelRadius << endl;
	Info<< "Iters:" << nIters << endl;

	ensure(relaxCL<=0.00000001,"relaxCL does not produce good results",0); // 

	for(int iter = 0; iter < nIters; iter++)
	{///    Volume-preserving Gaussian smoothing
	 if(iter==nIters-1) writeSurfaceFiles(facezsZ,pointsAll, "dumpSurfSmooth.vtk");
	  //for_(facezsZ, ifcs) 
	 for (int ifcs=facezsZ.size()-1; ifcs>=0; --ifcs) if(facezsZ[ifcs].size())
	 {const auto& facezs=facezsZ[ifcs]; 
	vars<point> newPoints(pointsAll);



		//const labelListList pFaces  = pointFaces(newPoints.size(),faces);
		const labelListList pointPoints = getPointPoints(newPoints.size(),facezs);


		labelList pMarks(pointPoints.size(),0);
		dbls pWeights(pointPoints.size(),1.0);
		vectorField pNw(pointPoints.size(),dbl3(0,0,0));
		dbls pAreas;
	  {// weits


		//for(const auto& facezs:facezsZ) 
		for(const auto& fac:facezs) for(const auto& pI:fac) // this only guaranties up to  3faces contact lines work ok
		{  int zn=fac.zone+1, pm=pMarks[pI]&255;  pMarks[pI] |= ((pm^zn)*(pm!=0))<<8 | zn;  }


		Info<< "\npMarks"<<ifcs<<": " << min(pMarks)<<" - "<< max(pMarks)<< "  "<<endl ;

		///. point-normal vectors
		 //vars<vectorField>  Cf=faceCentres(facezsZ,newPoints);

		 //vectorField pNs(pointPoints.size(),dbl3(0,0,0));
		
		 for(const auto& fac:facezs)   //for(const auto& facezs:facezsZ) 
		 {
			dbl3 cf = centre(fac,newPoints);
			for_(fac, pI)
			{   int e0=fac[pI], e1=fac[(pI+1)%4];
				dbl3 Ce=0.5*(newPoints[e0] + newPoints[e1]); 

				 dbl3 pNE=0.5*((newPoints[e0]-cf) ^ (Ce-cf)); 
				  pNw[e0] += pNE;
				 //if( pMarks[e0]==fac.zone ) {    pNw[e0] += pNE;     }// pNs[e0] += pNE;  
				 //else if( fac.zone != OWInd )        pNw[e0] += pNE;
				 //else                                pNs[e0] += pNE;

				 pNE=0.5*((newPoints[e1]-cf) ^ (Ce-cf));
				  pNw[e1] -= pNE; 
				 //if( pMarks[e1]==fac.zone ) {    pNw[e1] -= pNE;    } // pNs[e1] -= pNE;  
				 //else if( fac.zone != OWInd )        pNw[e1] -= pNE;
				 //else                                pNs[e1] -= pNE;//2.0*pNE-mag(pNE)*fNorms[faceI];
			}
		 }
		 pAreas=(mag(pNw));
		 Info<<"A: ["<<min(pAreas)<< "-"<<max(pAreas)<<"]="<<pAreas.avg(); cout.flush();

		 //pNs/=(mag(pNs)+1.0e-18);
		 pNw/=(mag(pNw)+1.0e-18);

		for(const auto& fac:facezs) for(const auto& pI:fac) if (pMarks[pI]!=fac.zone+1) { pWeights[pI]*=0.5; }
		/*for (int ii=0; ii<1; ++ii)
		{
			  //#// increase oil-water wait to reduce contact-line artifacts:		//for(auto& facezs:facezsZ)  for_(facezs[i],pi) if (pMarks[faces[i][pi]]==OWInd) { pWeights[faces[i][pi]]=4.0; } 


			dbls pWeightsOrig(pWeights);
			//vectorField pNwOrig(pNw);
			for_(pointPoints, vertI)
			{

				const ints& neiPoints = pointPoints[vertI];

				scalar avgPWeights(pWeightsOrig[vertI]);
				//dbl3 avgPPNw(pNwOrig[vertI]);
				scalar sumWeights(1.0);
				for_(neiPoints, neiPointI)
				{
					const int neiVertI = neiPoints[neiPointI];

					scalar weight=1.0;
					avgPWeights += weight * pWeightsOrig[neiVertI];
					//avgPPNw += weight * pNwOrig[neiVertI];
					sumWeights += weight;
				}
				if (sumWeights>0.5)
				{
					avgPWeights /= sumWeights;//myEdges.size();
					pWeights[vertI] =     0.1*avgPWeights + (1.0-0.1)*pWeightsOrig[vertI]; ///. 0.3 affects convergence,  smaller value makes cl faces bigger
					//pNw[vertI] =     0.3*avgPPNw + (1.0-0.3)*pNwOrig[vertI]; ///. 0.3 affects convergence,  smaller value makes cl faces bigger
				}
				//else
				//{
					//pWeights[vertI] = pWeightsOrig[vertI];
				//}

			}
		}*/

	  }

	 double avgA=pAreas.avg();
	 vectorField fNorms(facezs.size());
	 {
	 for_(facezs, fI)  fNorms[fI]=0.01*normal(facezs[fI],newPoints);
	 labelListList pFacess = pointFaces(newPoints.size(), facezs);
	 for_(pFacess, pI) {
		const auto& pfacs=pFacess[pI];
		for_(pfacs, fI)
		{
			if(pMarks[pI]==facezs[fI].zone+1)
			{
				 fNorms[fI]+=pNw[pI];
			}
			else
				 pAreas[pI]=(0.9*avgA+0.1*pAreas[pI]);
		}
	 }//for_(pFaces, pI) 
	 fNorms/=(mag(fNorms)+1.0e-32);
	 }

	 { //smoothing



	  const vectorField previousPoints(newPoints);
	  Info<< iter   <<"  "; cout.flush();
	  
	  for (int iKern=0; iKern<kernelRadius; ++iKern)
	  {
		vectorField displac(newPoints.size(),dbl3(0.,0.,0.));
		dbls        sumWeis(newPoints.size(),1.0e-64);
		 double wt;
		 for_(facezs, fI)   //for(const auto& facezs:facezsZ) 
		 {	const auto& fac=facezs[fI];
			for_(fac, pI)
			{	int e0=fac[pI], e1=fac[(pI+1)%4];
				dbl3 delp=newPoints[e1]-newPoints[e0];
				if(pMarks[e1]>pMarks[e0])
				{
					wt=0.9;       displac[e0]+=wt*delp;	sumWeis[e0]+=wt;
					dbl3 CL=fNorms[fI]^pNw[e1]; CL/=mag(CL)+1.0e-18;
					wt=0.5;  displac[e1]-=wt*((delp&CL)*CL);	sumWeis[e1]+=wt*0.3;
				} else if(pMarks[e0]>pMarks[e1])
				{
					dbl3 CL=fNorms[fI]^pNw[e0]; CL/=mag(CL)+1.0e-18;
					wt=0.5;  displac[e0]+=wt*((delp&CL)*CL);	sumWeis[e0]+=wt*0.3;
					wt=0.9;       displac[e1]-=wt*delp;   sumWeis[e1]+=wt;
				} else {
					wt=1.0;       displac[e0]+=wt*delp;	sumWeis[e0]+=wt*(1.0-0.5*(pMarks[e0]!=fac.zone+1));
					wt=1.0;       displac[e1]-=wt*delp;	sumWeis[e1]+=wt*(1.0-0.5*(pMarks[e1]!=fac.zone+1));;
				}
			}
		 }
		 displac/=sumWeis;
		 displac*=relax*0.5;
		 newPoints += displac;
	 }
		 /*
		//===========================================================================
		for (int iKern=0; iKern<kernelRadius; ++iKern)
		{
			
			vectorField displacements(newPoints.size(), dbl3(0,0,0));
			vectorField displacementsCL(newPoints.size(), dbl3(0,0,0));
			for_(pointPoints, vertI)
			{
				const ints& neiPoints = pointPoints[vertI];
				if(neiPoints.size())
				{

					dbl3 avgPos(0.0,0.0,0.0);
					scalar sumWeights(1.0e-18); 

					  for_(neiPoints, pJ)
					  {
							const int neiPI = neiPoints[pJ];
							scalar weight=(pAreas[neiPI]+0.9*pAreas[vertI]);
							//weight*=weight*pWeights[neiPI];
							//if (pMarks[neiPI] < pMarks[vertI]) weight*=0.05;
							avgPos += weight * newPoints[neiPI];
							sumWeights += weight;
					  }
				  
					if (sumWeights>0.1)
					{
						avgPos /= sumWeights;//myEdges.size();
						displacements[vertI] = avgPos-newPoints[vertI]; 
					}
				}



				if(neiPoints.size())
				//if ( (pMarks[vertI] & OWInd)==OWInd &&  (pMarks[vertI] & solidIndex))
				{ ///. contact line smoothing
					dbl3 avgPos(0.0,0.0,0.0);
					scalar sumWeights(1.0e-18); 
					for_(neiPoints, jj)
					{
						const label neiPI = neiPoints[jj];
						if (pMarks[neiPI] == pMarks[vertI])/// warning, also catches internal points All
						{
							scalar weight=1.0;
							avgPos += weight * newPoints[neiPI];
							sumWeights += weight;
						}
					}
					dbl3 DispCL =  (avgPos/sumWeights-newPoints[vertI]);
					//DispCL =  (DispCL & pNs[vertI])*pNs[vertI];
					displacementsCL[vertI] =  (DispCL );//- (DispCL & pNw[vertI])*pNw[vertI]);
					//displacementsCL[vertI] =  (DispCL & pNw[vertI])*pNw[vertI];
				}

			}

			Info  <<"Gauss "; cout.flush();
			newPoints += ((1.0-relaxParIntrf)*relax*(displacements & pNw))*pNw + (relaxParIntrf*relax)*displacements;
			newPoints += relaxCL*displacementsCL;

			Info<< " d:"<<mag(displacements).avg(); cout.flush();
		}
*/


		vectorField dispAvgO(newPoints-previousPoints);
		vectorField dispAvg(newPoints-previousPoints);


		Info<< "  disp:  "<<mag(dispAvg).avg(); cout.flush();

		Info <<"  VolPresev dAvg:"; cout.flush();

		/*for (int iKern=0; iKern<kernelRadius*1.5+2; ++iKern)
		{
			const vectorField dispAvgTmp(dispAvg);

			//~ vectorField NormalsOld(pNw);
			for_(pointPoints, vertI)
			{
				const ints& neiPoints = pointPoints[vertI];
				if(neiPoints.size())
				{
					scalar weight=pAreas[vertI];
					dbl3 avgDisp(weight*dispAvgTmp[vertI]);
					scalar sumWeights(weight);

					label currentLabel = pMarks[vertI];

					for_(neiPoints, jj)
					{
						const label neiPI = neiPoints[jj];

						//if( pMarks[neiPI]==currentLabel ) //| is correct
						{
							weight=pAreas[neiPI];
							if( pMarks[neiPI]!=currentLabel ) weight*=0.02;
							avgDisp += weight * dispAvgTmp[neiPI];
							sumWeights += weight;//*(0.1+0.9*(pMarks[neiPI]>=currentLabel) );
						}
					}
					dispAvg[vertI] = avgDisp*pWeights[vertI]/sumWeights;//myEdges.size();
				}
			}
		}*/
	  for (int iKern=0; iKern<kernelRadius+2; ++iKern)
	  {
		const vectorField dispAvgTmp(dispAvg);
		//vectorField displac(newPoints.size(),dbl3(0.,0.,0.));
		//dbls        sumWeis(newPoints.size(),1.0e-64);
		dbls        sumWeis(pAreas.size(),1.0e-64);
		dispAvg *= sumWeis;
		 for_(facezs, fI)   //for(const auto& facezs:facezsZ) 
		 {	const auto& fac=facezs[fI];
			double wt;
			for_(fac, pI)
			{	int e0=fac[pI], e1=fac[(pI+1)%4];
				//dbl3 delp=dispAvgTmp[e1]-dispAvgTmp[e0];
				if(pMarks[e1]>pMarks[e0])
				{
					wt=0.01*pAreas[e1];  dispAvg[e0]+=wt*((dispAvgTmp[e1]&fNorms[fI])*fNorms[fI]);	sumWeis[e0]+=wt;
					wt=0.9*pAreas[e1];  dispAvg[e1]+=wt*((dispAvgTmp[e0]&fNorms[fI])*fNorms[fI]);	sumWeis[e1]+=wt;
				} else if(pMarks[e0]>pMarks[e1])
				{
					wt=0.9*pAreas[e0];  dispAvg[e0]+=wt*((dispAvgTmp[e1]&fNorms[fI])*fNorms[fI]);	sumWeis[e0]+=wt;
					wt=0.01*pAreas[e0];  dispAvg[e1]+=wt*((dispAvgTmp[e0]&fNorms[fI])*fNorms[fI]);	sumWeis[e1]+=wt;
				} else {
					wt=pAreas[e1];  dispAvg[e0]+=wt*dispAvgTmp[e1];	sumWeis[e0]+=wt;
					wt=pAreas[e0];  dispAvg[e1]+=wt*dispAvgTmp[e0];	sumWeis[e1]+=wt;
				}
			}
		 }
		 dispAvg/=sumWeis;
		 //dispAvg*=pWeights;
		 //displac*=relax*0.5;
		 //newPoints += displac;
	 }

		//dispAvg   -= 0.3*(dispAvg-(dispAvg& pNw)*pNw);	 // to aalloow larger weight below to avoid sliding near boundary	//dispAvg -= 0.3*(dispAvg-(dispAvg& pNs)*pNs);
		newPoints -= 1.07*dispAvg;     ///.  TODO change 0.5 0.5,  sum should be 1



		pointsAll = newPoints;





	  if(iter==nIters-1) {
			std::vector<std::vector<face> > facess = getOrderedFaces(facezsZ, ifcs);
			ints pValidIs(pointsAll.size(),-1); int pInd=-1;
			for(auto&faces:facess) for(auto&fac:faces) for(auto& pi:fac) if(pValidIs[pi]==-1) pValidIs[pi]=++pInd;
			for(auto&faces:facess) for(auto&fac:faces) for(auto& pi:fac) pi=pValidIs[pi];

			fstream vtk("dumpSurfSmooth"+toStr(ifcs)+".vtk",ios::app);
			vtk<< "POINT_DATA " << pInd+1 << '\n'
			<< "FIELD attributes 3\n";

			dbls  pmrks(pInd+1);   for_i(pValidIs) if(pValidIs[i]!=-1) { pmrks[pValidIs[i]]=pMarks[i]; }
			vtk<< "\npmrks 1 " << pmrks.size() << " int\n" ;
			for_(pmrks,ii) vtk<<pmrks[ii]<<'\n';

			dbl3s dAvgs(pInd+1);   for_i(pValidIs) if(pValidIs[i]!=-1) { dAvgs[pValidIs[i]]=dispAvg[i]; }
			vtk<< "\ndAvgs 3 " << dAvgs.size() << " float\n" ;
			for_(dAvgs,ii) vtk<<dAvgs[ii]<<'\n';

			dbl3s dAvgO(pInd+1);   for_i(pValidIs) if(pValidIs[i]!=-1) { dAvgO[pValidIs[i]]=dispAvgO[i]; }
			vtk<< "\ndAvgO 3 " << dAvgO.size() << " float\n" ;
			for_(dAvgO,ii) vtk<<dAvgO[ii]<<'\n';
		}

		dispAvg=(newPoints-previousPoints);
		Info<< "  max:  "<<max(mag(dispAvg)); cout.flush();
		Info<< "  avgMag:  "<<mag(dispAvg).avg(); cout.flush();
		Info<< "  avg:  "<<dispAvg.avg(); cout.flush();
		Info<<endl;

	  Info<<"Gasss smoothed  :/"<<endl<<endl;

	  }
	}//===================================================================================



  }

	Info<<mag(pointsAll).avg()<< "  :avgMagPoints    "<<endl;
	Info<<max(mag(pointsAll))<< "  :maxMagPoints    "; cout.flush();


    Info << "End\n" << endl;

    return 0;
}


// ************************************************************************* //
